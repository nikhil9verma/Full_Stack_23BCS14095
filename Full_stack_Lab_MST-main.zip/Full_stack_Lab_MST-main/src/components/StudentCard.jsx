import React from 'react';

const StudentCard = ({ name, rollNo, course }) => {
  const cardStyle = {
    backgroundColor: '#9333ea',
    borderRadius: '10px',
    padding: '15px',
    color: 'white',
    marginBottom: '10px'
  };

  return (
    <div style={cardStyle}>
      <h3>{name}</h3>
      <p>Roll No: {rollNo}</p>
      <p>Course: {course}</p>
    </div>
  );
};

export default StudentCard;