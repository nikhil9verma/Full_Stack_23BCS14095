import React from 'react';

const TaskItem = ({ task, onToggle, onDelete }) => {
  return (
    <div className="flex items-center gap-2 p-2 bg-gray-100 rounded mb-2">
      <input
        type="checkbox"
        checked={task.completed}
        onChange={() => onToggle(task.id)}
        className="w-5 h-5"
      />
      <span className={task.completed ? 'line-through flex-1' : 'flex-1'}>
        {task.text}
      </span>
      <button
        onClick={() => onDelete(task.id)}
        className="bg-red-500 text-white px-3 py-1 rounded"
      >
        Delete
      </button>
    </div>
  );
};

export default TaskItem;
