import React, { useState } from 'react';
import TaskItem from './TaskItem';

const TodoList = () => {
  const [tasks, setTasks] = useState([
    { id: 1, text: 'Grade midterm exams', completed: false },
    { id: 2, text: 'Prepare lesson plan for next week', completed: false },
  ]);
  const [inputValue, setInputValue] = useState('');

  const addTask = () => {
    if (inputValue.trim()) {
      const newTask = {
        id: Date.now(),
        text: inputValue,
        completed: false
      };
      setTasks([...tasks, newTask]);
      setInputValue('');
    }
  };

  const toggleTask = (id) => {
    setTasks(tasks.map(task => 
      task.id === id ? { ...task, completed: !task.completed } : task
    ));
  };

  const deleteTask = (id) => {
    setTasks(tasks.filter(task => task.id !== id));
  };

  return (
    <div className="bg-white rounded-lg p-4">
      <h2 className="text-xl font-bold mb-4">My Tasks</h2>
      
      <div className="flex gap-2 mb-4">
        <input
          type="text"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          onKeyPress={(e) => e.key === 'Enter' && addTask()}
          placeholder="Add a new task..."
          className="flex-1 px-3 py-2 border rounded"
        />
        <button
          onClick={addTask}
          className="bg-blue-500 text-white px-4 py-2 rounded"
        >
          Add
        </button>
      </div>

      <div>
        {tasks.length === 0 ? (
          <p className="text-gray-500 text-center py-4">No tasks yet!</p>
        ) : (
          tasks.map(task => (
            <TaskItem
              key={task.id}
              task={task}
              onToggle={toggleTask}
              onDelete={deleteTask}
            />
          ))
        )}
      </div>

      {tasks.length > 0 && (
        <p className="mt-4 text-sm text-gray-600">
          Completed: {tasks.filter(t => t.completed).length} / {tasks.length}
        </p>
      )}
    </div>
  );
};

export default TodoList;