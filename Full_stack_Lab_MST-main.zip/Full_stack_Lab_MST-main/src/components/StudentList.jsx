import React from 'react';
import StudentCard from './StudentCard';

const StudentList = () => {
  const students = [
    { id: 1, name: 'Emma Johnson', rollNo: '2024001', course: 'Computer Science' },
    { id: 2, name: 'Liam Smith', rollNo: '2024002', course: 'Mathematics' },
    { id: 3, name: 'Olivia Brown', rollNo: '2024003', course: 'Physics' },
    { id: 4, name: 'Noah Davis', rollNo: '2024004', course: 'Chemistry' },
  ];

  return (
    <div className="bg-white rounded-lg p-4">
      <h2 className="text-xl font-bold mb-4">My Students</h2>
      <div>
        {students.map((student) => (
          <StudentCard
            key={student.id}
            name={student.name}
            rollNo={student.rollNo}
            course={student.course}
          />
        ))}
      </div>
    </div>
  );
};

export default StudentList;