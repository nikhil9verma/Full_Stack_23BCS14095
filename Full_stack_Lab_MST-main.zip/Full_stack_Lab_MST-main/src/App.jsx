import React from 'react';
import TodoList from './components/TodoList';
import StudentList from './components/StudentList';

const App = () => {
  return (
    <div className="min-h-screen p-8">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-4xl font-bold text-gray-800 mb-8 text-center">
          Teacher's Dashboard
        </h1>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <TodoList />
          <StudentList />
        </div>
      </div>
    </div>
  );
};

export default App;