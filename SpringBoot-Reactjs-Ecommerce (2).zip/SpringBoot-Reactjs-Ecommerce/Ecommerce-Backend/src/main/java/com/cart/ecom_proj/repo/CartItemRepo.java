package com.cart.ecom_proj.repo;

import com.cart.ecom_proj.model.CartItem;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CartItemRepo extends JpaRepository<CartItem, Long> {
}
