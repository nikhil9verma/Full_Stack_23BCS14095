package com.cart.ecom_proj.controller;

import com.cart.ecom_proj.dto.ChatRequest;
import com.cart.ecom_proj.dto.ChatResponse;
import com.cart.ecom_proj.service.ChatbotService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * ChatbotController
 * -----------------
 * Exposes REST endpoints for interacting with the AI chatbot.
 * Handles user questions and returns generated answers.
 */

@CrossOrigin(origins = "http://localhost:5173")
@RestController
@RequestMapping("/api/chatbot")
public class ChatbotController {

    private final ChatbotService chatbotService;

    public ChatbotController(ChatbotService chatbotService) {
        this.chatbotService = chatbotService;
    }

    /**
     * Endpoint: POST /api/chatbot/ask
     * 
     * Expects a JSON body like:
     * {
     * "question": "What laptops are available?"
     * }
     *
     * Returns:
     * {
     * "answer": "We have Dell, HP, and Lenovo laptops available..."
     * }
     */
    @PostMapping("/ask")
    public ResponseEntity<ChatResponse> ask(@RequestBody ChatRequest request) {
        // Validate request
        if (request.getQuestion() == null || request.getQuestion().isBlank()) {
            return ResponseEntity.badRequest()
                    .body(new ChatResponse("Please provide a valid question."));
        }

        // Ask chatbot service
        String answer = chatbotService.ask(request.getQuestion());
        return ResponseEntity.ok(new ChatResponse(answer));

    }

    /**
     * Optional: Simple GET endpoint for testing connectivity.
     */
    @GetMapping("/ping")
    public ResponseEntity<String> ping() {
        return ResponseEntity.ok("🤖 Chatbot API is running fine!");
    }
}
