package com.cart.ecom_proj.service;

import com.cart.ecom_proj.model.Product;
import com.cart.ecom_proj.repo.ProductRepo;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.hc.client5.http.classic.methods.HttpPost;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.core5.http.io.entity.StringEntity;
import org.apache.hc.core5.http.ContentType;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Chatbot service that connects to the Google Gemini API
 * using Apache HttpClient (not WebFlux).
 * It includes product information for context.
 */
@Service
public class ChatbotService {

    private final ProductRepo productRepo;
    private final ObjectMapper mapper = new ObjectMapper();

    @Value("${chatbot.api.url}")
    private String apiUrl;

    @Value("${chatbot.api.key}")
    private String apiKey;

    public ChatbotService(ProductRepo productRepo) {
        this.productRepo = productRepo;
    }

    public String ask(String question) {
        try {
            // 🧩 Step 1: Gather products for context
            List<Product> products = productRepo.findAll();
            String productContext = products.stream()
                    .map(p -> "Product: %s | Brand: %s | Price: %.2f | Category: %s".formatted(
                            p.getName(),
                            p.getBrand(),
                            p.getPrice() != null ? p.getPrice() : 0.0,
                            p.getCategory()))
                    .collect(Collectors.joining("\n"));

            // 🧩 Step 2: Build a natural-language prompt
            String prompt = "You are a shopping assistant. You know about the following products:\n\n"
                    + productContext
                    + "\n\nUser Question: " + question;

            // 🧩 Step 3: Build Gemini-compliant request body
            GeminiRequest body = new GeminiRequest(prompt);
            String requestBody = mapper.writeValueAsString(body);

            // 🧩 Step 4: Send POST request to Gemini API
            try (CloseableHttpClient client = HttpClients.createDefault()) {
                String fullUrl = apiUrl + "?key=" + apiKey;

                HttpPost request = new HttpPost(fullUrl);
                request.setHeader("Content-Type", "application/json");
                request.setEntity(new StringEntity(requestBody, ContentType.APPLICATION_JSON));

                var response = client.execute(request);
                int status = response.getCode();

                if (response.getEntity() != null) {
                    BufferedReader reader = new BufferedReader(
                            new InputStreamReader(response.getEntity().getContent()));
                    String json = reader.lines().collect(Collectors.joining());
                    System.out.println("Gemini raw response: " + json); // 🔍 Debug

                    if (status == 200) {
                        return extractAnswer(json);
                    } else {
                        try {
                            JsonNode err = mapper.readTree(json).path("error").path("message");
                            if (!err.isMissingNode()) {
                                return "Gemini API error: " + err.asText();
                            }
                        } catch (Exception ignored) {
                        }
                        return "Error: API returned status code " + status;
                    }
                } else {
                    return "Error: Empty response from Gemini API";
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            return "Error contacting chatbot API: " + e.getMessage();
        }
    }

    // ✅ Extract Gemini's answer text
    private String extractAnswer(String json) {
        try {
            JsonNode root = mapper.readTree(json);
            if (root.has("candidates")) {
                return root.get("candidates").get(0)
                        .get("content").get("parts").get(0)
                        .get("text").asText();
            }
            return "No valid answer found in response.";
        } catch (Exception e) {
            return "Error parsing Gemini response: " + e.getMessage();
        }
    }

    // ✅ Correct JSON structure for Gemini API
    static class GeminiRequest {
        public final Content[] contents;

        public GeminiRequest(String text) {
            this.contents = new Content[] { new Content(text) };
        }
    }

    static class Content {
        public final Part[] parts;

        public Content(String text) {
            this.parts = new Part[] { new Part(text) };
        }
    }

    static class Part {
        public final String text;

        public Part(String text) {
            this.text = text;
        }
    }
}
