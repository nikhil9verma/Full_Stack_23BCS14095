package com.cart.ecom_proj.service;

import com.cart.ecom_proj.model.Product;
import com.cart.ecom_proj.repo.ProductRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

@Service
public class ProductService {

    @Autowired
    private ProductRepo repo;

    // ✅ Get all products
    public List<Product> getAllProducts() {
        return repo.findAll();
    }

    // ✅ Get product by ID safely
    public Product getProductById(Long id) {
        return repo.findById(id).orElse(null);
    }

    // ✅ Add new product with image
    public Product addProduct(Product product, MultipartFile imageFile) throws IOException {
        if (imageFile != null && !imageFile.isEmpty()) {
            product.setImageName(imageFile.getOriginalFilename());
            product.setImageType(imageFile.getContentType());
            product.setImageData(imageFile.getBytes()); // ✅ corrected from imageDate → imageData
        }
        return repo.save(product);
    }

    // ✅ Update existing product with optional new image
    public Product updateProduct(Long id, Product updatedProduct, MultipartFile imageFile) throws IOException {
        Optional<Product> existingOpt = repo.findById(id);

        if (existingOpt.isEmpty()) {
            return null; // or throw an exception like new RuntimeException("Product not found")
        }

        Product existing = existingOpt.get();

        // Update fields
        existing.setName(updatedProduct.getName());
        existing.setDescription(updatedProduct.getDescription());
        existing.setBrand(updatedProduct.getBrand());
        existing.setPrice(updatedProduct.getPrice());
        existing.setCategory(updatedProduct.getCategory());
        existing.setReleaseDate(updatedProduct.getReleaseDate());
        existing.setProductAvailable(updatedProduct.isProductAvailable());
        existing.setStockQuantity(updatedProduct.getStockQuantity());

        // ✅ Update image only if a new file is uploaded
        if (imageFile != null && !imageFile.isEmpty()) {
            existing.setImageName(imageFile.getOriginalFilename());
            existing.setImageType(imageFile.getContentType());
            existing.setImageData(imageFile.getBytes()); // ✅ fixed
        }

        return repo.save(existing);
    }

    // ✅ Delete product by ID
    public void deleteProduct(Long id) {
        repo.deleteById(id);
    }

    // ✅ Search by keyword
    public List<Product> searchProducts(String keyword) {
        return repo.searchProducts(keyword);
    }
}
