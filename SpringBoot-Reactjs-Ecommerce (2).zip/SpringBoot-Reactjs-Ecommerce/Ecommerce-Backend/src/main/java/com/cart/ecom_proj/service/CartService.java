package com.cart.ecom_proj.service;

import com.cart.ecom_proj.model.*;
import com.cart.ecom_proj.repo.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class CartService {

    @Autowired
    private CartRepo cartRepo;

    @Autowired
    private ProductRepo productRepo;

    public Cart getCart(String userIdentifier) {
        return cartRepo.findByUserIdentifier(userIdentifier)
                .orElseGet(() -> cartRepo.save(new Cart(userIdentifier)));
    }

    public Cart addToCart(String userIdentifier, Long productId, int quantity) {
        Cart cart = getCart(userIdentifier);
        Product product = productRepo.findById(productId)
                .orElseThrow(() -> new RuntimeException("Product not found"));

        // Check if product already in cart
        for (CartItem item : cart.getItems()) {
            if (item.getProduct().getId().equals(productId)) {
                item.setQuantity(item.getQuantity() + quantity);
                cartRepo.save(cart);
                return cart;
            }
        }

        // Add new item
        CartItem newItem = new CartItem(product, quantity);
        cart.addItem(newItem);
        cartRepo.save(cart);
        return cart;
    }

    public Cart removeFromCart(String userIdentifier, Long productId) {
        Cart cart = getCart(userIdentifier);
        cart.getItems().removeIf(item -> item.getProduct().getId().equals(productId));
        return cartRepo.save(cart);
    }

    public void clearCart(String userIdentifier) {
        Cart cart = getCart(userIdentifier);
        cart.getItems().clear();
        cartRepo.save(cart);
    }

    public List<CartItem> getCartItems(String userIdentifier) {
        return getCart(userIdentifier).getItems();
    }
}
