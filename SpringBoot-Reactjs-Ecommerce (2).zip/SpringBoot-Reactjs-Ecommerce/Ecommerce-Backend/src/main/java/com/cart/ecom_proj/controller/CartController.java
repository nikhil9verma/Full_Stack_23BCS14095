package com.cart.ecom_proj.controller;

import com.cart.ecom_proj.model.Cart;
import com.cart.ecom_proj.model.CartItem;
import com.cart.ecom_proj.service.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/api/cart")
public class CartController {

    @Autowired
    private CartService cartService;

    @GetMapping("/{user}")
    public List<CartItem> getCartItems(@PathVariable String user) {
        return cartService.getCartItems(user);
    }

    @PostMapping("/{user}/add")
    public Cart addToCart(@PathVariable String user,
            @RequestParam Long productId,
            @RequestParam(defaultValue = "1") int quantity) {
        return cartService.addToCart(user, productId, quantity);
    }

    @DeleteMapping("/{user}/remove/{productId}")
    public Cart removeFromCart(@PathVariable String user, @PathVariable Long productId) {
        return cartService.removeFromCart(user, productId);
    }

    @DeleteMapping("/{user}/clear")
    public void clearCart(@PathVariable String user) {
        cartService.clearCart(user);
    }
}
