package com.cart.ecom_proj.service;

import com.cart.ecom_proj.model.User;
import com.cart.ecom_proj.repo.UserRepo;
import com.cart.ecom_proj.security.JwtUtil;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    @Autowired
    private UserRepo userRepo;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtUtil jwtService;

    /**
     * Registers a new user in the database
     * 
     * @param username user's name
     * @param email    user's email
     * @param password user's raw password
     * @return success or error message
     */
    public String register(String username, String email, String password) {
        // ✅ Check if email already exists
        if (userRepo.existsByEmail(email)) {
            return "Email already registered!";
        }

        // ✅ Create and save user with encoded password
        User user = new User();
        user.setUsername(username);
        user.setEmail(email);
        user.setPassword(passwordEncoder.encode(password)); // BCrypt encoding
        userRepo.save(user);

        return "User registered successfully!";
    }

    /**
     * Authenticates the user and returns a JWT token if successful
     * 
     * @param email    user's email
     * @param password user's raw password
     * @return JWT token or invalid message
     */
    public String login(String email, String password) {
        Optional<User> optionalUser = userRepo.findByEmail(email);
        if (optionalUser.isEmpty()) {
            return "Invalid email";
        }

        User user = optionalUser.get();

        if (!passwordEncoder.matches(password, user.getPassword())) {
            return "Invalid password";
        }

        // ✅ Pass user email (String) to generateToken
        return jwtService.generateToken(user.getEmail());
    }
}
