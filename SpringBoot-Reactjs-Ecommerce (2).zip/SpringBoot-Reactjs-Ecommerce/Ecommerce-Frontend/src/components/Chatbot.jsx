// src/components/Chatbot.jsx
import React, { useState, useRef, useEffect } from "react";
import axios from "axios";
import "./Chatbot.css";

export default function Chatbot({ onClose }) {
  const [question, setQuestion] = useState("");
  const [messages, setMessages] = useState([]); // { from: 'user'|'bot', text }
  const [loading, setLoading] = useState(false);
  const inputRef = useRef(null);

  useEffect(() => {
    // focus input when opened
    if (inputRef.current) inputRef.current.focus();
  }, []);

  const sendQuestion = async () => {
    const q = question.trim();
    if (!q) return;
    const newMessages = [...messages, { from: "user", text: q }];
    setMessages(newMessages);
    setQuestion("");
    setLoading(true);

    try {
      const res = await axios.post("http://localhost:8080/api/chatbot/ask", { question: q });
      const answer = res.data?.answer || "No answer from server.";
      setMessages((m) => [...m, { from: "bot", text: answer }]);
    } catch (err) {
      console.error("chatbot error", err);
      setMessages((m) => [...m, { from: "bot", text: "Sorry, an error occurred. Try again later." }]);
    } finally {
      setLoading(false);
    }
  };

  const handleKey = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendQuestion();
    }
  };

  return (
    <div className="chatbot-wrapper">
      <div className="chatbot-header">
        <div>Catalog Assistant</div>
        <button className="chatbot-close" onClick={onClose}>✖</button>
      </div>

      <div className="chatbot-body">
        {messages.length === 0 && <div className="chatbot-hint">Ask about products (e.g., "show me laptops under 6000", or "do you have Dell XPS").</div>}
        {messages.map((m, idx) => (
          <div key={idx} className={`chat-message ${m.from === "user" ? "user" : "bot"}`}>
            <div className="chat-text">{m.text}</div>
          </div>
        ))}
        {loading && <div className="chat-message bot"><div className="chat-text">Thinking...</div></div>}
      </div>

      <div className="chatbot-footer">
        <textarea
          ref={inputRef}
          className="chatbot-input"
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          onKeyDown={handleKey}
          placeholder="Type your question and press Enter"
          rows={2}
        />
        <button className="chatbot-send" onClick={sendQuestion} disabled={loading || !question.trim()}>
          Send
        </button>
      </div>
    </div>
  );
}
