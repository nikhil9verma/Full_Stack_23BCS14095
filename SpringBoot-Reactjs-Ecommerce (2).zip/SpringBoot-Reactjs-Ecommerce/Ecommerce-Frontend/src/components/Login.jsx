import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");
  const navigate = useNavigate();

  const handleLogin = async () => {
    if (!email || !password) {
      setMessage("Please fill in all fields.");
      return;
    }

    try {
      const res = await axios.post("http://localhost:8080/api/auth/login", {
        email,
        password,
      });

      if (res.data.token) {
        localStorage.setItem("token", res.data.token);
        setMessage("✅ Login successful!");
        setTimeout(() => navigate("/"), 1000); // redirect to homepage
      } else {
        setMessage("⚠️ Invalid response from server.");
      }
    } catch (err) {
      if (err.response && err.response.status === 401) {
        setMessage("❌ Invalid email or password!");
      } else {
        setMessage("⚠️ Server error. Please try again later.");
      }
    }
  };

  return (
    <div className="container  col-md-4 card p-4 shadow  pt-5 mt-5 ">
      <h3 className="text-center mb-3">Login</h3>
      <input
        type="email"
        className="form-control mb-3"
        placeholder="Enter email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
      />
      <input
        type="password"
        className="form-control mb-3"
        placeholder="Enter password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />
      <button className="btn btn-primary w-100" onClick={handleLogin}>
        Login
      </button>
      <p className="mt-3 text-center text-muted">{message}</p>
    </div>
  );
};

export default Login;
