import React, { useEffect, useState } from "react";
import Chatbot from "./Chatbot"; // ensure Chatbot.jsx is in same folder or adjust path
import axios from "axios";

const Navbar = ({ onSelectCategory, onSearch }) => {
  const [showBot, setShowBot] = useState(false); // ✅ chatbot toggle
  const [selectedCategory, setSelectedCategory] = useState("");
  const [theme, setTheme] = useState(() => localStorage.getItem("theme") || "light-theme");
  const [input, setInput] = useState("");
  const [searchResults, setSearchResults] = useState([]);
  const [noResults, setNoResults] = useState(false);
  const [showSearchResults, setShowSearchResults] = useState(false);

  useEffect(() => {
    document.body.className = theme;
    localStorage.setItem("theme", theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme((prev) => (prev === "dark-theme" ? "light-theme" : "dark-theme"));
  };

  const fetchData = async () => {
    try {
      const response = await axios.get("http://localhost:8080/api/products");
      setSearchResults(response.data);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleChange = async (value) => {
    setInput(value);
    if (value.length >= 1) {
      setShowSearchResults(true);
      try {
        const response = await axios.get(
          `http://localhost:8080/api/products/search?keyword=${value}`
        );
        setSearchResults(response.data);
        setNoResults(response.data.length === 0);
      } catch (error) {
        console.error("Error searching:", error);
      }
    } else {
      setShowSearchResults(false);
      setSearchResults([]);
      setNoResults(false);
    }
  };

  const handleCategorySelect = (category) => {
    setSelectedCategory(category);
    onSelectCategory(category);
  };

  const categories = [
    "Laptop",
    "Headphone",
    "Mobile",
    "Electronics",
    "Toys",
    "Fashion",
  ];

  return (
    <>
      <header>
        <nav className="navbar navbar-expand-lg fixed-top bg-light shadow-sm">
          <div className="container-fluid">
            <a
              className="navbar-brand fw-bold text-primary"
              href="/"
            >
              HiTeckKart
            </a>

            <button
              className="navbar-toggler"
              type="button"
              data-bs-toggle="collapse"
              data-bs-target="#navbarSupportedContent"
              aria-controls="navbarSupportedContent"
              aria-expanded="false"
              aria-label="Toggle navigation"
            >
              <span className="navbar-toggler-icon"></span>
            </button>

            <div className="collapse navbar-collapse" id="navbarSupportedContent">
              <ul className="navbar-nav me-auto mb-2 mb-lg-0">
                <li className="nav-item">
                  <a className="nav-link active" aria-current="page" href="/">
                    Home
                  </a>
                </li>
                <li className="nav-item">
                  <a className="nav-link" href="/add_product">
                    Add Product
                  </a>
                </li>

                <li className="nav-item dropdown">
                  <a
                    className="nav-link dropdown-toggle"
                    href="/"
                    role="button"
                    data-bs-toggle="dropdown"
                    aria-expanded="false"
                  >
                    Categories
                  </a>

                  <ul className="dropdown-menu">
                    {categories.map((category) => (
                      <li key={category}>
                        <button
                          className="dropdown-item"
                          onClick={() => handleCategorySelect(category)}
                        >
                          {category}
                        </button>
                      </li>
                    ))}
                  </ul>
                </li>
              </ul>

              {/* Theme toggle */}
              <button className="btn btn-outline-secondary me-2" onClick={toggleTheme}>
                {theme === "dark-theme" ? (
                  <i className="bi bi-moon-fill"></i>
                ) : (
                  <i className="bi bi-sun-fill"></i>
                )}
              </button>

              {/* Cart Link */}
              <a href="/cart" className="btn btn-outline-dark me-2">
                <i className="bi bi-cart"></i> Cart
              </a>

              {/* Chatbot Toggle Button */}
              <button
                className="btn btn-primary"
                onClick={() => setShowBot(true)}
              >
                Chatbot
              </button>

              {/* Search Bar */}
              <div className="position-relative ms-3">
                <input
                  className="form-control"
                  type="search"
                  placeholder="Search"
                  aria-label="Search"
                  value={input}
                  onChange={(e) => handleChange(e.target.value)}
                />

                {showSearchResults && (
                  <ul
                    className="list-group position-absolute w-100 mt-1"
                    style={{ zIndex: 1050, maxHeight: "200px", overflowY: "auto" }}
                  >
                    {searchResults.length > 0 ? (
                      searchResults.map((result) => (
                        <li key={result.id} className="list-group-item">
                          <a
                            href={`/product/${result.id}`}
                            className="text-decoration-none text-dark"
                          >
                            {result.name}
                          </a>
                        </li>
                      ))
                    ) : (
                      noResults && (
                        <li className="list-group-item text-muted">
                          No Product Found
                        </li>
                      )
                    )}
                  </ul>
                )}
              </div>
            </div>
          </div>
        </nav>
      </header>

      {/* ✅ Render Chatbot when active */}
      {showBot && <Chatbot onClose={() => setShowBot(false)} />}
    </>
  );
};

export default Navbar;
