import axios from "axios";
import { useState, useEffect, createContext } from "react";

const AppContext = createContext({
  data: [],
  isError: "",
  cart: [],
  addToCart: (product) => {},
  removeFromCart: (productId) => {},
  refreshData: () => {},
  clearCart: () => {},
});

export const AppProvider = ({ children }) => {
  const [data, setData] = useState([]);
  const [isError, setIsError] = useState("");
  const [cart, setCart] = useState([]);

  // Temporary static user identifier until authentication is added
  const USER_ID = "guest";

  // ✅ Fetch all products
  const refreshData = async () => {
    try {
      const response = await axios.get("http://localhost:8080/api/products");
      setData(response.data);
    } catch (error) {
      setIsError(error.message);
    }
  };

  // ✅ Fetch cart from backend
  const fetchCart = async () => {
    try {
      const response = await axios.get(`http://localhost:8080/api/cart/${USER_ID}`);
      const backendCart = response.data.map((item) => ({
        id: item.product.id,
        name: item.product.name,
        brand: item.product.brand,
        price: item.product.price,
        quantity: item.quantity,
        category: item.product.category,
        stockQuantity: item.product.stockQuantity,
      }));
      setCart(backendCart);
      localStorage.setItem("cart", JSON.stringify(backendCart));
    } catch (error) {
      console.error("Error fetching cart:", error);
      // fallback to localStorage if backend fails
      const storedCart = JSON.parse(localStorage.getItem("cart")) || [];
      setCart(storedCart);
    }
  };

  // ✅ Add to cart (syncs with backend)
  const addToCart = async (product) => {
    try {
      await axios.post(
        `http://localhost:8080/api/cart/${USER_ID}/add`,
        null,
        {
          params: {
            productId: product.id,
            quantity: 1,
          },
        }
      );
      await fetchCart(); // refresh cart from backend
    } catch (error) {
      console.error("Error adding to cart:", error);
      alert("Failed to add to cart. Please try again.");
    }
  };

  // ✅ Remove item from cart (backend)
  const removeFromCart = async (productId) => {
    try {
      await axios.delete(`http://localhost:8080/api/cart/${USER_ID}/remove/${productId}`);
      await fetchCart();
    } catch (error) {
      console.error("Error removing from cart:", error);
      alert("Failed to remove item from cart.");
    }
  };

  // ✅ Clear entire cart
  const clearCart = async () => {
    try {
      await axios.delete(`http://localhost:8080/api/cart/${USER_ID}/clear`);
      setCart([]);
      localStorage.removeItem("cart");
    } catch (error) {
      console.error("Error clearing cart:", error);
    }
  };

  // Load data + cart when app starts
  useEffect(() => {
    refreshData();
    fetchCart();
  }, []);

  // Sync localStorage whenever cart updates
  useEffect(() => {
    localStorage.setItem("cart", JSON.stringify(cart));
  }, [cart]);

  return (
    <AppContext.Provider
      value={{
        data,
        isError,
        cart,
        addToCart,
        removeFromCart,
        refreshData,
        clearCart,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export default AppContext;
